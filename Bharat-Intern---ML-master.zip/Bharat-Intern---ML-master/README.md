# Bharat-Intern---ML

In this repository i completed the tasks that i got in the Machine Learning internship from Bharat Intern.

**TASK : 1**

*House Price Prediction :*

"Machine Learning model to predict house price using linear regression only Jupyter notebook code.."

Dataset : https://drive.google.com/file/d/1r5YDbOOFpgQr-O_XCSVa1RMVQWBeAlXv/view?usp=sharing

**TASK : 2** 

*Wine Quality Prediction :*

"Machine Learning model to predict the quality of wine using linear regression only Jupyter notebook code."

In this project i also used flask to deploy our Machine Learning model in a simple html web site.

Dataset : https://drive.google.com/file/d/1ql-stlf9sFA9MYVq1xszZ3IB_9FAkK4E/view?usp=sharing

**TASK : 3**

*Iris Flowers Classification :*

"Predict the different species of flowers on the length of there petals and sepals only Jupyter notebook code."

Dataset : https://drive.google.com/file/d/1BjuNlhtTIvaeOE_Cr_CoHNmHGxHZbzjq/view?usp=sharing







